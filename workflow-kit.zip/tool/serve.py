from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import json,threading,importlib.util
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('edit',ROOT/'tool/edit.py');edit=importlib.util.module_from_spec(spec);spec.loader.exec_module(edit)
state={'state':'ready'};lock=threading.Lock()
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT),**kw)
 def do_GET(self):
  if self.path=='/status':
   data=json.dumps(state).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
  else:super().do_GET()
 def do_POST(self):
  if self.path!='/export':self.send_error(404);return
  if not lock.acquire(False):self.send_error(409);return
  def task():
   try:state.update(state='exporting');r=edit.run();state.update(state='complete',result=r)
   except Exception as e:state.update(state='failed',error=str(e))
   finally:lock.release()
  threading.Thread(target=task,daemon=True).start();self.send_response(202);self.end_headers()
ThreadingHTTPServer(('127.0.0.1',8770),Handler).serve_forever()
