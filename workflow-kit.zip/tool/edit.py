"""Local, deterministic 3-clip edit. Requires Python 3 + FFmpeg in PATH.
No account, network service, paid API, AI inference, or cloud upload.
Run from the review folder: python3 tool/edit.py
Original source shots are in inputs/ and remain untouched.
"""
from pathlib import Path
import subprocess,json,time,hashlib
ROOT=Path(__file__).resolve().parents[1]
def run():
 paths=[ROOT/'inputs'/f'clip{i+1}.mp4' for i in range(3)]
 for p in paths:
  if not p.exists():raise FileNotFoundError(p)
 args=['ffmpeg','-v','error','-y']
 for p in paths:args+=['-i',str(p)]
 # Cross-fades join three 3-second camera shots into an 8.3-second edit.
 filters=';'.join(f'[{i}:v]fps=24,scale=1280:720,setsar=1,settb=AVTB,setpts=PTS-STARTPTS[v{i}]' for i in range(3))
 filters+=';[v0][v1]xfade=transition=fade:duration=0.35:offset=2.65[x];[x][v2]xfade=transition=fade:duration=0.35:offset=5.30,format=yuv420p[out]'
 args+=['-filter_complex',filters,'-map','[out]','-an','-c:v','libx264','-preset','veryfast','-crf','19','-threads','2','-movflags','+faststart',str(ROOT/'finished-edit.mp4')]
 start=time.perf_counter();subprocess.run(args,check=True)
 result={'input_count':3,'input_seconds_each':3,'output_seconds_expected':8.3,'transition_seconds':.35,'output_sha256':hashlib.sha256((ROOT/'finished-edit.mp4').read_bytes()).hexdigest(),'elapsed_seconds':round(time.perf_counter()-start,3),'external_requests':0,'method':'Deterministic FFmpeg recipe, not AI editing','input_hashes':[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]}
 (ROOT/'actual-export.json').write_text(json.dumps(result,indent=2));return result
if __name__=='__main__':print(json.dumps(run(),indent=2))
